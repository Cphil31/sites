<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?= TITRE ?></title>
		<link href="css/commerce.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>
		<header></header>
		<div id="container">
			<div class="categorie">
				<a href="index.php">Produits</a> &gt; Produit indisponible
			</div>
		</div>
		<footer></footer>
	</body>
</html>
