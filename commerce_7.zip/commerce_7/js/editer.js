function annuler() {
	location = 'index.php';
}
