function detail(id_produit) {
	location = `detail.php?id_produit=${id_produit}`;
}

function editer(id_categorie) {
	location = `editer.php?id_categorie=${id_categorie}`;
}
