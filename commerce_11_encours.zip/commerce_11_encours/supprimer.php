<?php

require_once 'inc/cfg.php';
$opt = ['options' => ['min_range' => 1]];
$id_produit = filter_input(INPUT_GET, 'id_produit', FILTER_VALIDATE_INT, $opt);
if ($id_produit) {
	$req = "DELETE FROM produit WHERE id_produit={$id_produit}";
	$pdo->exec($req);
	@unlink("img/prod_{$id_produit}_v.jpg");
	@unlink("img/prod_{$id_produit}_p.jpg");
}