function detail(id_produit) {
	location = `detail.php?id_produit=${id_produit}`;
}
